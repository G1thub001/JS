package assignment2.assignment2;

import java.io.Serializable;


public class AssociateCustomer extends Customer implements Serializable{
    ///Stores the payingCustomer tied to the associate
    private PayingCustomer m_payingCustomer;
    
    /**
    * Overloaded Default constructor 
    */
    AssociateCustomer(String name, String email, Address address, Type type){
        SetName(name);
        SetEmail(email);
        SetAddress(address);
        SetType(type);
    }
    
    /**
    * Getter for the paying customer
    * @return m_payingCustomer
    */
    public PayingCustomer GetPayingCustomer(){
        return m_payingCustomer;
    }
    
    /**
    * Setter for the paying customer
    * @param payingCustomer
    */
    public void SetPayingCustomer(PayingCustomer payingCustomer){
        m_payingCustomer = payingCustomer;
    }
}
