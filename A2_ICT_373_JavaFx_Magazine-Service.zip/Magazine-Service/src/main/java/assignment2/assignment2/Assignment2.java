package assignment2.assignment2;

public class Assignment2 {

    public static void main(String[] args) {
        GUI gui = new GUI();
        gui.Run();
    }
}
