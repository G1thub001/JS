package assignment2.assignment2;

import java.io.Serializable;


public class DirectDebit extends PaymentMethod implements Serializable{
    /// Stores bank account number
    private String m_bankAccount;
    
    /**
    * Getter for the bank account number - Overrides parent method
    * @return m_bankAccount
    */
    public String GetPaymentInformation(){
        return m_bankAccount;
    }
    
    /**
    * Setter for the bank account number - Overrides parent method
    * @param information
    */
    public void SetPaymentInformation(String information){
        m_bankAccount = information;
    }
}
