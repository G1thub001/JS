package assignment2.assignment2;

import java.io.Serializable;


public class CreditCard extends PaymentMethod implements Serializable{
    /// Stores credit card number
    private String m_creditCardNumber;
    
    /**
    * Getter for the credit card number - Overrides parent method
    * @return m_creditCardNumber
    */
    public String GetPaymentInformation(){
        return m_creditCardNumber;
    }
    
    /**
    * Setter for the credit card number - Overrides parent method
    * @param information
    */
    public void SetPaymentInformation(String information){
        m_creditCardNumber = information;
    }
}
